from sklearn.ensemble import RandomForestClassifier
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.base import BaseEstimator

from sklearn.grid_search import GridSearchCV
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC

class Classifier(BaseEstimator):
    def __init__(self):
        pass

    def fit(self, X, y):
    
        self.n_components = 13
        self.pca = PCA(n_components=self.n_components)
        d = {"A":0, "B":1, "Q":2, "R":3}
        y=[d[k] for k in y]
        
        svm = SVC(kernel='rbf', C=1e6, probability=True)

        CLF = Pipeline(steps = [ ('pca', self.pca), ('clf', svm) ])
        
        
        CLF.fit(X,y)
        
        self.clf = CLF.named_steps['clf']
        self.pca = CLF.named_steps['pca']
        X = self.pca.fit_transform(X)
        self.clf.fit(X, y)
                    


    def predict(self, X):
        
        X = self.pca.transform(X)
        
        y = self.clf.predict(X)
        
        return y_pred

    def predict_proba(self, X):
        
        X = self.pca.transform(X)
        
        y_pred = self.clf.predict_proba(X)
        
        return y_pred