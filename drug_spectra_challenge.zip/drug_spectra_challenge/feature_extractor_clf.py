import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import Imputer
from sklearn.preprocessing import normalize

class FeatureExtractorClf(object):
    def __init__(self):
        #self.le = LabelEncoder()
        pass

    def fit(self, X_df, y_df):
        #for i in ['solute', 'vial'] :
        #X_df['solute'].values = self.le.fit(X_df['solute'].values, y_df['molecule'].values)
        #X_df['vial'].values = self.le.fit(X_df['vial'].values, y_df['molecule'].values)
        pass
    
    def transform(self, X_df):
        #for i in ['solute', 'vial'] :
        #X_df['vial'].values = self.le.transform(X_df['vial'].values)
        #X_df['solute'].values = self.le.transform(X_df['solute'].values)
        XX = np.array([np.array(dd) for dd in X_df['spectra']])
        XX = normalize(XX, norm='l2', axis=1, copy=True, return_norm=False)
        #for i in range(len(X_df['spectra'])):
            #X_df['spectra'][i] = XX[i]
        return XX